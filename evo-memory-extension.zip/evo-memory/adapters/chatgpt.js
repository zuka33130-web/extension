// Adaptador de ChatGPT. TODO lo específico del sitio vive SOLO aquí.
// ⚠ Los selectores pueden cambiar: verificalos con DevTools (ver README, sección 2).
(function (root) {
  const EVO = (root.EVO = root.EVO || {});
  const SEL = {
    message: '[data-message-author-role]',
    composer: '#prompt-textarea, div.ProseMirror[contenteditable="true"]',
    stop: '[data-testid="stop-button"], button[aria-label*="Stop" i], button[aria-label*="Detener" i]'
  };

  EVO.adapter = {
    name: 'chatgpt',
    conversationId: () => (location.pathname.match(/\/c\/([\w-]+)/) || [])[1] || 'nueva',
    isStreaming: () => !!document.querySelector(SEL.stop),

    getMessages() {
      return [...document.querySelectorAll(SEL.message)].map((el, i) => {
        const role = el.getAttribute('data-message-author-role');
        const id = el.getAttribute('data-message-id') || `${role}-${i}`;
        const code = [...el.querySelectorAll('pre')].map((pre) => {
          const c = pre.querySelector('code');
          const lang = ((c && c.className.match(/language-([\w+#-]+)/)) || [])[1] || '';
          return { lang, code: (c || pre).innerText };
        });
        return { id, role, text: el.innerText, code };
      });
    },

    // Escribe en el cuadro de texto SIN enviar: el envío siempre lo hace la persona.
    insertText(text) {
      const box = document.querySelector(SEL.composer);
      if (!box) return false;
      box.focus();
      if (box.tagName === 'TEXTAREA') {
        const set = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
        set.call(box, (box.value ? box.value + '\n\n' : '') + text);
        box.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      }
      const sel = getSelection();
      sel.selectAllChildren(box);
      sel.collapseToEnd();
      return document.execCommand('insertText', false, text);
    }
  };
})(globalThis);
